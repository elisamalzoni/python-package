def world():
    print("Hello world")