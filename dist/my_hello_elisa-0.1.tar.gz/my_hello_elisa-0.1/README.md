Pacote com Hello World

https://github.com/insper/dev-aberto